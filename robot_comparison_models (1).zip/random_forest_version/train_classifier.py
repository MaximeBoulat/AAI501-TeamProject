import os
import numpy as np
import joblib
from sklearn.ensemble import RandomForestClassifier
from sensors import read_sensors

world_dir = "worlds"
X, y = [], []

for file in os.listdir(world_dir):
    if file.endswith(".npy"):
        world = np.load(os.path.join(world_dir, file))
        goal = tuple(np.argwhere(world == 3)[0])
        start = tuple(np.argwhere(world == 2)[0])
        pos = start
        for _ in range(30):
            features = read_sensors(world, pos, goal)
            for idx, direction in enumerate([(-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1),(1,-1),(1,1)]):
                X.append(features)
                y.append(idx)
clf = RandomForestClassifier(n_estimators=100)
clf.fit(X, y)
joblib.dump(clf, "robot_model_rf.joblib")
print("✅ Random Forest model trained and saved.")